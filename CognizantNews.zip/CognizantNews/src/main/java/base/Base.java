package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.ExtentReport;

public class Base {
	public FileInputStream fis;
	public Properties prop;
	public static WebDriver driver;
	public static ExtentTest logger;
	public File f;
	public ExtentReports report=ExtentReport.getReportInstance();
	
	
	public void browserSetup() throws FileNotFoundException, IOException {
		
		//Declaring Properties File 
		//And Loading the Config file
		fis=new FileInputStream("C:\\eclipse workspace\\CognizantNews\\src\\main\\java\\utilities\\propertiesFile");
		prop=new Properties();
		prop.load(fis);
		
		//Getting the Browser Name from Properties File
		//Invoking respective Browser
		if(prop.getProperty("BrowserName").equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if(prop.getProperty("BrowserName").equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		//Maximizing the Window
		driver.get(prop.getProperty("WebsiteUrl"));
		driver.manage().window().maximize();
	}
	
	public void screenShots(String ssName) throws IOException {
		//Taking Screenshots of the window into a file 
		f=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\eclipse workspace\\CognizantNews\\OutputFiles\\Screenshots\\"+ssName));
	}
	
	public void reportFail(String report) {
		//Fail report Status
		logger.log(Status.FAIL, report);
	}
	
	public void reportPass(String report) {
		//Pass Report Status
		logger.log(Status.PASS, report);
	}
	
	public void endReport() {
		//Flushing the report
		report.flush();
	}
	
	public void closeBrowser() {
		//CLosing the driver
		driver.close();
		driver.quit();
	}

}
