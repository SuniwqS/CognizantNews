package pages;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Base;

public class Login extends Base{
	
	WebDriver driver;
	
	public Login(WebDriver driver2) {
		this.driver=driver2;
		PageFactory.initElements(driver2, this);
	}
	
	@FindBy(xpath="//*[@id=\"i0116\"]")
	WebElement userid;
	
	@FindBy(id="idSIButton9")
	WebElement next;
	
	@FindBy(id="i0118")
	WebElement pwd;
	
	@FindBy(id="idSIButton9")
	WebElement signin;
	
	@FindBy(xpath="//*[@id=\"idDiv_SAOTCS_Proofs\"]/div[3]/div/div/div[2]/div")
	WebElement call;
	
	@FindBy(xpath="//*[@id=\"lightbox\"]/div[3]/div/div[2]/div/div[3]/a")
	WebElement notNow;
	
	@FindBy(id="idSIButton9")
	WebElement yes;
	
	
	
	public void userId(String id) throws IOException {
		//Entering the user id
		logger = report.createTest("Signing in to Be.Cognizant");
		userid.sendKeys(id);
		screenShots("userid.png");
		reportPass("Entering User Id");
	}
	

	public void clickNext() {
		next.click();
	}
	
	public void userPwd(String pass) throws IOException {
		//entering the user password
		pwd.sendKeys(pass);
		
		reportPass("Entering User Password");
	}
	
	public void clickSignIn() throws IOException, InterruptedException {
		Thread.sleep(2000);
		screenShots("Password.png");
		signin.click();
		reportPass("Signing in");
	}
	
	public void clickCall() {
		call.click();
	}
	
	public void clickNotnow() throws InterruptedException, IOException {
		
		Thread.sleep(7000);
		screenShots("notnow.png");
		notNow.click();
	}
	
	public void clickYes() {
		yes.click();
	}
}
