package pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import base.Base;

public class HomePage extends Base{

	WebDriver driver;
	WebDriverWait wait;
	
	public HomePage(WebDriver driver2) {
		this.driver=driver2;
		PageFactory.initElements(driver2, this);
	}
	
	@FindBy(xpath="//*[@id=\"userProfileToggleBtn\"]/div/div[2]")
	WebElement userdetails;
	
	@FindBy(className="site-link-hover")
	WebElement aroundCognizant;
	
	@FindBy(xpath="//a[contains(text(),'View All')]")
	WebElement viewall;
	
	
	public void getUserDetails() throws IOException {
		//Using logger to log the report
		//Obtaining the user details and printing them
		//taking screenshots of the page
		logger = report.createTest("Retrieving User details and Validating Around Cognizant title");
		System.out.println(userdetails.getText());
		screenShots("UserDetails.png");
		reportPass("User details are Obtained");
	}

	public void validateTitle() throws InterruptedException {
		//Scrolling down the page
		//Obtaining the around cognizant title
		JavascriptExecutor jse=(JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,1200)");
		String actual=aroundCognizant.getText();
		String expected="AROUND COGNIZANT";
		//Using assertion to validate the title
		Assert.assertEquals(actual, expected,"The Title has been Validated");
		System.out.println("Around Cognizant title has been Validated");
		reportPass("AROUND COGNIZANT is Obtained");
	}
	
	public void clickViewAll() throws InterruptedException {
		//Navigating to AroundCognizant page
		Thread.sleep(5000);
		viewall.click();
	}
}
