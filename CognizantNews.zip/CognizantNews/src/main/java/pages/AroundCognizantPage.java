package pages;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.Base;

public class AroundCognizantPage extends Base{

	WebDriver driver;
	
	public AroundCognizantPage(WebDriver driver2) {
		this.driver=driver2;
		PageFactory.initElements(driver2, this);
		//Handling the windows using window Handler
		String parentWindowHandle=driver.getWindowHandle();
		//Switching to the new Window
		Set<String> windowHandles=driver.getWindowHandles();
		for(String windowHandle : windowHandles) {
			if(!windowHandle.equals(parentWindowHandle)) {
				driver.switchTo().window(windowHandle);
			}
		}
	}
	
	@FindBy(xpath="//body/div[@id='ng2-view']/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/search-centre[1]/div[1]/div[1]/div[2]/override-template-or-fallback[1]/ul[1]/li[2]/search-centre-layout[1]/div[1]/focusable-group[1]/span[2]/button[1]/span[1]")
	WebElement gridview;
	
	@FindBy(xpath="//body[1]/div[1]/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/search-centre[1]/div[1]/div[1]/div[2]/override-template-or-fallback[1]/ul[1]/li[3]/search-centre-total[1]")
	WebElement noofresults;
	
	@FindBy(xpath="//body/div[@id='ng2-view']/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/search-centre[1]/div[1]/div[1]/div[2]/override-template-or-fallback[1]/ul[1]/li[4]/search-centre-sort[1]/div[1]/button[1]")
	WebElement dd;
	
	@FindBy(xpath="//body/div[@id='ng2-view']/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/search-centre[1]/div[1]/div[1]/div[2]/override-template-or-fallback[1]/ul[1]/li[4]/search-centre-sort[1]/div[1]/ul[1]")
	WebElement validatedd;
	
	@FindBy(xpath="//label[contains(text(),'Exact Matches Only')]")
	WebElement exactmatches;
	
	@FindBy(xpath="//button[contains(text(),'Today')]")
	WebElement today;
	
	public void clickGridView() throws InterruptedException {
		//Entering the report into the log
		logger = report.createTest("Checking UI and Navigating to Today's News");
		Thread.sleep(5000);
		//Clicking on the grid view to change the view
		gridview.click();
		reportPass("Changing to Grid view");
	}
	
	public void noOfResults() {
		//Printing the no of results
		System.out.println(noofresults.getText());
		reportPass("Results are Obatained");
	}
	
	public void clickOnDropDown() throws InterruptedException {
		//clicking on drop down 
		//printing the drop down menu
		dd.click();
		Assert.assertEquals(dd.getText(), "Newest");
		System.out.println("The Status Available for Dropdown :\n"+validatedd.getText());
		reportPass("DropDown values are Obtained");
	}
	
	public void clickOnExactMatches() {
		//Obtaining the Url and printing the url
		String before=driver.getCurrentUrl();
		System.out.println("URL before clicking on ExactMatchesOnly : \n"+before);
		//clicking on exactmatchesonly 
		//Obtaining the url and printing
		exactmatches.click();
		String after=driver.getCurrentUrl();
		System.out.println("URL after clicking on ExactMatchesOnly : \n"+after);
		//Checking if exactMatchesOnly is appending or not
		if(after.endsWith("exactMatchesOnly")) {
			System.out.println("exactMatchesOnly has been appended");
		}
		else {
			System.out.println("exactMatchesOnly has not been appended");
		}
		reportPass("checking the ExactMatchesOnly CheckBox");
	}
	
	public void clickOnToday() throws IOException {
		//Navigating to today's news
		today.click();
		reportPass("Navigating to todays News");
		screenShots("AroundCognizantPage.png");
	}
}
