package pages;

import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.Base;

public class NewsTodayPage extends Base{

	WebDriver driver;
	WebDriverWait wait;
	
	public NewsTodayPage(WebDriver driver2) {
		//PageFactory is used to initialize driver
		this.driver=driver2;
		PageFactory.initElements(driver2, this);	
	}
	//Finding the element results 
	@FindBy(xpath="//body[1]/div[1]/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/search-centre[1]/div[1]/div[1]/div[2]/override-template-or-fallback[1]/ul[1]/li[3]/search-centre-total[1]")
	WebElement results;
	
	public void retrieveNews() throws InterruptedException, IOException {
		//Using logger to create log of the report 
		logger = report.createTest("Navigating to every news and retrieving data");
		Thread.sleep(5000);
		//Retrieving the result 
		//Converting the String result into integer
		try {
		String re=results.getText();
		String r=re.substring(0, 1);
		int res=Integer.parseInt(r);
		//Taking ScreenShot of the page
		//printing the total number of news
		screenShots("Today's News.png");
		System.out.println("Total number of today's news :"+res);

		Thread.sleep(3000);
		for(int i=1;i<=res;i++) {
			Thread.sleep(5000);
			//Iterating over the number of news
			//Finding the news and clicking
			driver.findElement(By.xpath("/html[1]/body[1]/div[1]/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/search-centre[1]/div[1]/div[1]/div[2]/override-template-or-fallback[1]/div[1]/focusable-group[1]/search-centre-results[1]/div["+i+"]/div[1]/a[1]/span[1]")).click();
			Thread.sleep(5000);
			//Obtaining the data and saving it into the String news
			// And Printing the news
			String news=driver.findElement(By.xpath("//body/div[@id='ng2-view']/app-root[1]/main[1]/div[1]/unily-spa[1]/dynamic-content-viewer[1]/section[1]/upgrade-component-wrapper[1]/div[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div[1]")).getText();
			System.out.println(news);
			//XWPFDocumnet is used to operate the word file
			//Creating paragraphs and run 
			XWPFDocument document=new XWPFDocument();
			XWPFParagraph paragraph=document.createParagraph();
			XWPFRun run=paragraph.createRun();
			//Writing the news into the word 
			run.setText(news);
			try {
				//Creating and writing the word File
				FileOutputStream output=new FileOutputStream("C:\\eclipse workspace\\CognizantNews\\OutputFiles\\"+"News"+i+".docx");
				document.write(output);
				output.close();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			document.close();
			Thread.sleep(2000);
			//Navigating back to the previous page
			driver.navigate().back();
		}
		reportPass("Today's News is Obtained");
		}
		catch(Exception e) {
			System.out.println("No News For Today");
			reportPass("No News for Today");
		}
	}
}
