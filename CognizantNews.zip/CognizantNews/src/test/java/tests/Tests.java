package tests;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.Base;
import pages.AroundCognizantPage;
import pages.HomePage;
import pages.Login;
import pages.NewsTodayPage;

public class Tests extends Base{
	public Properties prop;
	public FileInputStream fis;
	Scanner sc=new Scanner(System.in);
	
	
	Base t=new Base();
	@BeforeTest
	public void invokeBrowser() throws FileNotFoundException, IOException {
		logger = report.createTest("Execution of Test Cases");
		fis=new FileInputStream("C:\\eclipse workspace\\CognizantNews\\src\\main\\java\\utilities\\propertiesFile");
		prop=new Properties();
		prop.load(fis);
		t.browserSetup();
		reportPass("Browser is Invoked");
	}
	@Test(priority=0)
	public void loggingin() throws InterruptedException, IOException {
		Login l=new Login(driver);
		Thread.sleep(3000);
		l.userId(sc.next());
		l.clickNext();
		reportPass("User Id is Entered");
		l.userPwd(sc.next());
		Thread.sleep(3000);
		reportPass("User Password is Entered");
		l.clickSignIn();
		reportPass("Signed in Successfully");
		l.clickCall();
		Thread.sleep(10000);
		l.clickNotnow();
		l.clickYes();
		
	}
	@Test(priority=1)
	public void mainPage() throws InterruptedException, IOException {
		HomePage t1=new HomePage(driver);
		t1.getUserDetails();
		reportPass("Retrieved User Details");
		t1.validateTitle();
		reportPass("Around Cognizant title is retrieved and Validated");
		Thread.sleep(5000);
		t1.clickViewAll();
	}
	@Test(priority=2)
	public void newsPage() throws InterruptedException, IOException {
		AroundCognizantPage ac=new AroundCognizantPage(driver);
		ac.clickGridView();
		reportPass("View is changed to GRID view");
		ac.noOfResults();
		reportPass("Results are retrieved");
		ac.clickOnDropDown();
		reportPass("Printed the Drop Down");
		ac.clickOnExactMatches();
		reportPass("Checked the CheckBox and ExactMatchesOnly is appended");
		ac.clickOnToday();
		reportPass("Navigated to today's News");
	}
	@Test(priority=3)
	public void newsToday() throws InterruptedException, IOException {
		NewsTodayPage nt=new NewsTodayPage(driver);
		nt.retrieveNews();
		reportPass("Today's News Data Retrieved");
		
	}
	@AfterTest
	public void closeBrowser() {
		t.endReport();
		t.closeBrowser();
	}
}
